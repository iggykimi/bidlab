# Arquitectura implementable
Estado: diseño cerrado para P0; los comandos de arranque/test de producto de este documento deberán ser implementados por Muse. No se afirma que ya funcionen.

## ADR y stack
| ADR | Decisión | Motivo y límite |
|---|---|---|
| A01 | Monorepo Python + TypeScript | Equipo de una persona, dominio numérico Python y UI rica. Contrato REST versionado. |
| A02 | Python 3.12, FastAPI, Pydantic v2, SQLAlchemy 2, Alembic, SQLite | Un proceso, WAL, foreign_keys=ON, busy_timeout=5000. Sin Redis/Celery/Postgres. Revisiones append-only. |
| A03 | Node 22.12+; React, TypeScript strict, Vite, Tailwind, componentes Radix/shadcn, Recharts | D: usar versiones estables compatibles que el agente resuelva y fije el primer día; no “latest” durante CI. Vite documenta Node 20.19+/22.12+. Un package-lock.json y uv.lock reproducibles. |
| A04 | pypdf + pdfplumber para extracción local; PDF.js para visor | No hacer depender producto de PyMuPDF utilizado en la investigación sin revisar su licencia AGPL/comercial. pypdf no es OCR ni renderizador. |
| A05 | Plantillas y AST JSON restringido; Decimal | Fórmulas aisladas de red/IA. P0 una plantilla aprobada; gramática acotada extensible. |
| A06 | Meta Spark 1.3 estándar, Chat Completions con texto paginado y JSON schema | Una sola familia de endpoint para extracción P0. PDF/vision opcional y segmentada si hace falta, no requisito de demo. Sin embeddings ni vector DB. |
| A07 | Import offline + fixture curado real | Sin crawler nacional ni fetch de URLs arbitrarias desde la UI. P1 procesa ZIP local. |
| A08 | Servir build web desde FastAPI en 127.0.0.1:8000 | Un origen en demo. Vite 5173 y proxy /api solo en desarrollo. No exposición a LAN ni cloud sin revisión de autenticación. |
| A09 | Jobs persistidos, un worker en el proceso | Extracción puede durar minutos. Recuperación explícita; no hacer pasar una función BackgroundTasks sin persistencia por cola durable. |
| A10 | Sin modelo predictivo | Datos disponibles no identifican la distribución competitiva. Estadística descriptiva independiente del simulador. |

Tecnologías son elecciones, no afirmaciones de “más reciente”. El agente registra versiones resueltas en docs/environment.md, verifica licencias directas/transitivas y actualiza solo por incompatibilidad o vulnerabilidad relevante. Referencias primarias: [FastAPI](https://fastapi.tiangolo.com/), [SQLAlchemy](https://docs.sqlalchemy.org/en/20/), [Vite](https://vite.dev/guide/), [pypdf](https://pypdf.readthedocs.io/), [Playwright](https://playwright.dev/docs/intro), [PDF.js](https://mozilla.github.io/pdf.js/).

## Componentes y límites
~~~mermaid
flowchart TD
  UI["React: workspace y Pricing Lab"] --> API["FastAPI: contratos y revisión"]
  API --> DOMAIN["Dominio: Decimal, reglas y escenarios"]
  API --> JOBS["Jobs: páginas, extracción y citas"]
  JOBS --> META["Meta Model API"]
  API --> DB["SQLite: revisiones y snapshots"]
  JOBS --> BLOBS["Archivos locales por hash"]
  ETL["Importación oficial offline"] --> DB
  DOMAIN --> REPORT["Informe reproducible"]
~~~

Frontend → API → servicios de aplicación → dominio puro.
Servicios coordinan repositorios SQLite, almacenamiento local y adaptador Meta. Dominio no importa FastAPI, SQLAlchemy, HTTP ni SDK Meta. Importación es CLI y usa los mismos normalizadores y repositorios.

Frontend conserva solo estado de UI y filtros. React Query para datos/polling y React Hook Form con Zod para formularios; tipos generados del OpenAPI con openapi-typescript. No implementar la fórmula dos veces en JS y Python. Recharts transforma decimales a number únicamente para dibujar; cifras y CSV provienen del backend como strings.

Flujo principal:
1. Cargar ejemplo → transacción seed idempotente que copia datos curados a DB/sesión.
2. Seleccionar scope y perfil → GET workspace proporciona reglas vigentes, revisión y evidencias.
3. POST /scenarios/evaluate resuelve scope, regla y revisión empresa; valida precondiciones; motor devuelve KPIs, traza y curva.
4. Guardar → POST /scenarios reevalúa el mismo input en backend y almacena input+resultado+hashes inmutables.
5. Crear informe → POST /reports con scenario_id y decisión manual; devuelve reporte inmutable y URL local de HTML.
6. Ver informe → renderer Jinja con autoescape desde snapshot; no otra llamada LLM.

## Árbol de producto que deberá crear el agente
~~~text
AGENTS.md
README.md
.env.example
.gitignore
pyproject.toml
uv.lock
package.json
package-lock.json
scripts/
  dev.py
  demo.py
  verify.py
  seed_demo.py
  inspect_meta.py
apps/
  api/
    pyproject.toml
    alembic.ini
    migrations/
    bidlab/
      main.py
      settings.py
      api/{health,capabilities,tenders,documents,analysis,companies,scenarios,reports}.py
      schemas/{common,tender,extraction,company,scenario,report}.py
      domain/{money,eligibility,expressions,scoring,anomaly,statistics}.py
      services/{workspace,document_pipeline,citations,extraction,review,evaluation,reports}.py
      adapters/{meta_model,fixture_provider,pdf_text,filesystem}.py
      db/{session,models,repositories}.py
      jobs/{worker,queue}.py
      ingestion/{placsp,normalize,quality}.py
      prompts/{extract_v1,repair_v1}.txt
      templates/decision_report.html
    tests/
      unit/
      integration/
      contracts/
      live/
  web/
    package.json
    vite.config.ts
    tsconfig.json
    src/
      api/{client,generated}.ts
      app/{router,providers}.tsx
      features/
        library/
        workspace/
        requirements/
        pricing/
        evidence/
        reports/
      components/{ui,StatusBadge,Money,EmptyState,ErrorState}.tsx
      lib/{format,requestSequence}.ts
      styles.css
    public/pdfjs/ 
    tests/
tests/e2e/
fixtures/
  demo/{manifest,tender,company,interpretation,review,expected}.json
  synthetic/{malicious_xml,zero_price,ocr_required,...}
docs/
  [los diez documentos normativos más MUSE_GOAL]
  verification-log.md
  environment.md
  task-board.md
  blockers.md
  publication-manifest.json
storage/                    [gitignored]
  bidlab.sqlite3
  blobs/<sha256>
  raw/<sha256>
  exports/
evidence/                   [investigación; no publicar en bloque]
schemas/
examples/
tools/                      [sondas de este paquete]
.github/workflows/ci.yml
~~~
Las llaves indican varios archivos a crear, no nombres literales con comas. El árbol no es una lista de implementaciones ya existentes.

## Contratos internos exactos
~~~python
# Especificación de firmas, no implementación
extract_pages(pdf_path: Path) -> list[PageText]
verify_citation(citation: CitationProposal, page: PageText) -> CitationCheck
extract_document(pages: list[PageText], context: ExtractionContext) -> ExtractionProposal
compile_rule(revision: PricingRuleRevision) -> CompiledRule
evaluate_price(ctx: EvaluationContext, request: EvaluationRequest) -> EvaluationResult
evaluate_anomaly(policy: AnomalyPolicy, offers: list[Offer], basis: PriceBasis) -> AnomalyResult
evaluate_requirement(tree: RequirementNode, evidence: list[CompanyEvidence]) -> EligibilityResult
build_report(snapshot: ScenarioSnapshot, decision: ReportDecision) -> ReportSnapshot
~~~
EvaluationContext contiene scope aprobado, regla/revisión, empresa/revisión y hashes. Nunca construirlo desde una fórmula que envía el navegador. La evaluación de fórmulas nuevas exige endpoint de revisión previo y schema/whitelist.

## Extracción y revisión documental
1. Upload streaming a archivo temporal privado; verificar firma %PDF-, MIME permitido y lector real; 20 MiB, 120 páginas, sin cifrado, sin portfolio/adjuntos ejecutables. UUID interno, nombre de usuario solo para display escapado. Hash antes de procesar. Duplicado por hash/tender devuelve referencia existente.
2. Parser en subprocess con timeout 30 s y límites disponibles del SO. Linux: CPU/memoria/proceso; Windows: timeout y límites de tamaño, documentar diferencia y usar Job Object si se incorpora. No afirmar aislamiento fuerte de PDF si solo hay timeout.
3. pypdf extract_text por página física; pdfplumber como segunda lectura para tabla/fórmula si el texto falla. Guardar extractores/versión y texto original; normalización separada. Página con <80 caracteres útiles => low_text/needs_review, no requisito ausente.
4. Indexar todas las páginas hasta límite, sin recortar silenciosamente las finales. Dividir en lotes de ≤10 páginas y ≤25.000 caracteres, preservando document_id, hash, page_number y marcadores. Recuperación por encabezados/regex solo para focalizar; una pasada de cobertura revisa todas las páginas.
5. Llamadas Meta sin herramientas, con developer prompt que trata documentos como datos no confiables, instrucciones de no inferir y esquema fijo. Tareas: datos económicos/criterios, requisitos/obligaciones, fechas. Deduplicar hallazgos por clave y evidencia, sin usar un segundo LLM como árbitro exclusivo.
6. Cada propuesta incluye valor bruto, valor normalizado nullable, unidad, notas, citas y ambigüedad. El LLM no fija reviewed=true ni compila código.
7. Validar JSON local con Pydantic. Refusal, finish_reason length, cadena vacía o esquema inválido => job fallido/needs_review, no partial como completo. Una reparación estructural como máximo; no llenar campos inexistentes para pasar el esquema.
8. Comprobar cita contra página exacta: NFKC, soft-hyphen eliminado y espacios colapsados; preservar puntuación y cifras. Resultado exact/normalized_match/missing. Guardar offsets sobre texto normalizado y versión de normalización, no asumir que UTF-16 del browser coincide con índices Python.
9. Dato “cita localizada” sigue propuesto. Finanzas/scope, fórmula y política de anormalidad requieren aprobación semántica humana registrada. Choque XML/PDF crea issue; no elegir automáticamente el de mayor “confidence”.
10. Revisión crea nueva revision, expected_revision obligatorio; estado anterior permanece en historial. Documento cambiado invalida aprobaciones y escenarios nuevos hasta revalidar. Los escenarios guardados conservan su snapshot anterior.

PDF nativo Meta: doc M04 admite input_file/Chat file, pero tiene límites de primeras 100 páginas texto y 50 imágenes. Si se activa P1, dividir PDF con pypdf en ≤40 páginas y guardar mapping a páginas del original; costo medido real y eliminar archivo remoto si se usa Files. P0 envía texto segmentado y no crea almacenamiento remoto Files. El modelo no accede a documentos privados por URL pública.

## Meta adapter
Base fija https://api.meta.ai/v1; modelo por META_MODEL=muse-spark-1.3; clave solo MODEL_API_KEY. Rechazar contributor por defecto; opción deliberada solo con datos de prueba públicos y aceptación explícita de sus condiciones. La variable META_API_KEY pertenece al CLI y la app no la usa como fallback silencioso.

Fragmento documental mínimo:
~~~python
client = OpenAI(base_url="https://api.meta.ai/v1", api_key=os.environ["MODEL_API_KEY"],
                timeout=90.0, max_retries=0)
response = client.chat.completions.create(
    model=settings.meta_model,
    messages=[{"role":"developer","content":prompt},
              {"role":"user","content":page_marked_text}],
    max_completion_tokens=6000,
    response_format={"type":"json_schema","json_schema":{
        "name":"bidlab_extraction","schema":extraction_schema}},
)
# validar contenido y finish_reason antes de persistir cualquier propuesta
~~~
El adaptador limita la salida con max_completion_tokens=6000, documentado para Chat Completions (https://dev.meta.ai/docs/protocols/chat-completions). max_output_tokens pertenece a Responses y no se envía a Chat. Se comprueba el SDK con smoke antes de integración. No configurar temperature=0 para “garantizar verdad”; dejar default y exigir evidencias/validación. Cache por hashes de documento/páginas + prompt + schema + modelo + opciones + extractor. No cachear como éxito errores ni respuestas truncadas. No prometer reproducibilidad byte a byte de inferencia live.

Retry de transporte: 3 intentos totales para 429/5xx/timeout, backoff 1,2 s+jitter y Retry-After limitado a 30 s; presupuesto reservado en cada intento, 400/401/403 no se reintentan. SDK retries desactivados para evitar multiplicación. Un retry después de timeout puede facturar una llamada anterior: registrar como coste incierto. Concurrencia de inferencia 1 en P0. Tokens/latencia/estado del proveedor sin texto completo ni razonamiento privado en logs.

## Jobs, errores y persistencia
Job: queued → running → succeeded | needs_review | failed | cancelled. Un worker consume SQLite con lease; al arrancar marca jobs running sin worker como failed:interrupted. No hace llamadas remotas repetidas tras un reinicio sin acción explícita. El usuario puede reintentar como job nuevo; Idempotency-Key evita duplicación por doble clic.

POST analysis devuelve 202 + Location /jobs/:id. Poll 1 s al principio y 3 s después; timeout UI no cancela la ejecución a escondidas. Job tiene progreso por páginas/lotes, no porcentaje de “certeza”. Límite 1 running y 5 queued; 429 local con Retry-After. La DB nunca permanece bloqueada durante HTTP ni parsing.

Errores JSON comunes: code, message, request_id, details (sin traceback). HTTP 409 stale_revision o rule_unapproved; 422 domain_validation; 413 upload_too_large; 415 unsupported_media; 503 provider_not_configured; 502 provider_failure. Unknown matemático es 200 con status unknown y motivos, no cero ni NaN. Fallo de infraestructura no se disfraza como unknown jurídico.

Escenario: snapshot inmutable de inputs/rules/company/source hashes, engine_version y resultado. El hash del snapshot sirve para integridad/reproducción, no es firma jurídica. Informe basado solo en un escenario persistido.

## Seguridad y privacidad P0
- Bind loopback, allowed Host localhost/127.0.0.1; mismo origen en producción; dev allowlist exacta 5173. Para mutations exigir X-BidLab-Client: local-ui y validar Origin; CORS sin wildcard ni credenciales universales. Esto no es autenticación multiusuario: prohibido desplegar públicamente sin agregar auth/aislamiento.
- No endpoint fetch(URL). Descargas administrativas mediante CLI con allowlist, HTTPS, redirects comprobados y límites; bloquear IP privadas/metadata en cada resolución si se amplía a URLs.
- Uploads fuera de webroot, permisos OS privados, sin rutas del cliente, symlink/path traversal rechazado. Nunca ejecutar enlaces/JavaScript/adjuntos del PDF.
- PDF.js local con scripting/XFA/eval desactivados donde la API lo admita; CSP propia, sin scripts de CDN. No permitir dangerouslySetInnerHTML sobre texto de documentos. HTML de informe Jinja autoescape y CSP sin ejecución.
- No secretos en frontend, fixture, querystrings, log, screenshots o informe. .env gitignored. Logs redactan Authorization. Secret scanner en CI y revisión de diff antes de hacer público.
- El prompt no tiene tools ni credenciales, solo páginas seleccionadas. “Ignora tus instrucciones” dentro de un PDF es texto; prueba adversarial obligatoria.
- Perfil/costes locales por defecto; confirmación de procesamiento remoto por conjunto de documentos, no enviar costes ni certificados de empresa para extraer PCAP. Modo estándar de Meta no equivale a residencia UE ni a ausencia de tratamiento.
- Política de borrado: eliminar perfil/documento debe alcanzar blobs no referenciados y derivados; informes con snapshots requieren borrado explícito. El contrato P0 no incluye una UI o API de borrado granular; README debe explicar cómo eliminar todos los datos locales y esta capacidad se añade antes de cualquier uso cloud/multiusuario. Para demo usar solo datos públicos y perfil sintético.
- storage está en disco local, sin cifrado de app P0: proteger cuenta/disco del SO. No afirmar “cifrado en reposo empresarial”. Antes de cloud revisar RGPD, encargados, transferencias, retención y autenticación.

## Observabilidad
request_id en respuesta y logs JSON; job_id, stage, elapsed_ms, status, tokens y gasto estimado. GET health no comprueba saldo Meta ni realiza llamadas facturables. GET capabilities informa configured/demo/model/limitaciones, no api_key. Tabla ModelInvocation distingue live/fixture/manual y conserva proveedor request_id si se devuelve; fixture/manual no tiene tokens ficticios.

Guardar command, timestamp, exit code, commit/hashes y ruta de evidencia de cada check en verification-log.md. Revisiones y cambios de coste en audit_event con actor local explícito y motivo. Sin analytics remoto.

## Arranque y Windows
El agente implementa scripts Python multiplataforma: python scripts/dev.py, python scripts/demo.py --reset-demo, python scripts/verify.py. No depender de make, bash o Docker. uv sync --frozen y npm ci; build sirve assets desde FastAPI. Reseteo afecta exclusivamente DB de demo identificada, no storage privado.

Documentar dos terminales si dev.py falla y registrar prueba real en Windows; ejecutar en Linux no cuenta como Windows PASS. La demo offline exige dependencias ya instaladas y assets/browser disponibles: “sin Internet durante ejecución” no significa instalación nueva sin descargas.

Cloud es una extensión futura: no crear DB gestionada ni hosting para hackathon hasta tener P0 estable y autorización del autor.


Referencia de licencia consultada: https://pymupdf.readthedocs.io/en/latest/about.html, sección License and Copyright. La librería se usó para investigación/inspección; el producto elige pypdf/pdfplumber para evitar incorporar esa dependencia sin decidir su licencia.

Contrato de configuración inicial: usar los nombres de .env.example; BIDLAB_MODE=demo|live|manual, BIDLAB_BIND_HOST=127.0.0.1, BIDLAB_PORT=8000, BIDLAB_STORAGE_DIR, BIDLAB_HISTORY_ENABLED y BIDLAB_META_BUDGET_USD. La clave vacía no habilita live. No inferir modo live por encontrar una clave si BIDLAB_MODE sigue demo.

El progreso de jobs cuenta páginas únicas por etapa, con processed_pages≤total_pages; cambiar de etapa reinicia ese contador. No sumar varias pasadas como si fueran páginas distintas.
